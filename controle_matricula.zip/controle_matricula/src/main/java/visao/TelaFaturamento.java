package visao;

import conexao.Conexao;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TelaFaturamento extends JInternalFrame {
    private JTextField txtDataInicio, txtDataFim;
    private JComboBox<String> comboDisciplina;
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    
    public TelaFaturamento() {
        initComponents();
        carregarDisciplinas();
    }
    
    private void initComponents() {
        setTitle("💰 Faturamento por Período");
        setSize(800, 550);
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Estilos.COR_FUNDO);
        
        // Painel de filtros
        JPanel panelFiltros = Estilos.criarPainelComBorda("📅 Filtros de Período");
        panelFiltros.setLayout(new GridLayout(3, 2, 10, 10));
        panelFiltros.setBorder(BorderFactory.createCompoundBorder(
            panelFiltros.getBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        panelFiltros.add(criarLabel("Data Início (YYYY-MM-DD):*"));
        txtDataInicio = criarTextField();
        panelFiltros.add(txtDataInicio);
        
        panelFiltros.add(criarLabel("Data Fim (YYYY-MM-DD):*"));
        txtDataFim = criarTextField();
        panelFiltros.add(txtDataFim);
        
        panelFiltros.add(criarLabel("Disciplina:"));
        comboDisciplina = new JComboBox<>();
        comboDisciplina.setFont(Estilos.FONTE_NORMAL);
        panelFiltros.add(comboDisciplina);
        
        // Painel de botões
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotoes.setBackground(Color.WHITE);
        
        JButton btnConsultar = Estilos.criarBotaoPrimario("💰 Consultar Faturamento");
        btnConsultar.addActionListener(e -> consultarFaturamento());
        panelBotoes.add(btnConsultar);
        
        JButton btnLimpar = Estilos.criarBotaoSecundario("🧹 Limpar");
        btnLimpar.addActionListener(e -> limparCampos());
        panelBotoes.add(btnLimpar);
        
        // Tabela
        modeloTabela = new DefaultTableModel(
            new Object[]{"Disciplina", "Período", "Total Matrículas", "Faturamento Total"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabela = new JTable(modeloTabela);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setFont(Estilos.FONTE_NORMAL);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(Estilos.FONTE_NEGRITO);
        tabela.getTableHeader().setBackground(Estilos.COR_PRIMARIA);
        tabela.getTableHeader().setForeground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Estilos.COR_PRIMARIA, 1), 
            "📊 Resultado do Faturamento", 
            0, 0, 
            Estilos.FONTE_NEGRITO, 
            Estilos.COR_PRIMARIA
        ));
        
        // Layout principal
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(Estilos.COR_FUNDO);
        panelNorte.add(panelFiltros, BorderLayout.CENTER);
        panelNorte.add(panelBotoes, BorderLayout.SOUTH);
        
        panel.add(panelNorte, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        getContentPane().add(panel);
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(Estilos.FONTE_NEGRITO);
        label.setForeground(Estilos.COR_TEXTO);
        return label;
    }
    
    private JTextField criarTextField() {
        JTextField field = new JTextField();
        field.setFont(Estilos.FONTE_NORMAL);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }
    
    private void carregarDisciplinas() {
        String sql = "SELECT codigo, nomeDisciplina FROM disciplina ORDER BY nomeDisciplina";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            comboDisciplina.removeAllItems();
            comboDisciplina.addItem("Todas as disciplinas");
            
            while (rs.next()) {
                comboDisciplina.addItem(rs.getString("nomeDisciplina") + " (" + rs.getInt("codigo") + ")");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao carregar disciplinas: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void consultarFaturamento() {
        if (txtDataInicio.getText().isEmpty() || txtDataFim.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Informe as datas de início e fim no formato YYYY-MM-DD.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        modeloTabela.setRowCount(0);
        
        String dataInicio = txtDataInicio.getText();
        String dataFim = txtDataFim.getText();
        
        String sql = "SELECT d.nomeDisciplina, m.periodo, " +
                    "COUNT(m.idmat) as totalMatriculas, " +
                    "SUM(m.valorPago) as faturamentoTotal " +
                    "FROM matricula m " +
                    "INNER JOIN disciplina d ON m.disciplina = d.codigo " +
                    "WHERE m.dataMatricula BETWEEN ? AND ? ";
        
        if (!comboDisciplina.getSelectedItem().equals("Todas as disciplinas")) {
            String disciplinaSelecionada = comboDisciplina.getSelectedItem().toString();
            int codigoDisciplina = Integer.parseInt(disciplinaSelecionada.split("\\(")[1].replace(")", ""));
            sql += "AND m.disciplina = ? ";
        }
        
        sql += "GROUP BY d.nomeDisciplina, m.periodo " +
               "ORDER BY faturamentoTotal DESC";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, dataInicio);
            stmt.setString(2, dataFim);
            
            if (!comboDisciplina.getSelectedItem().equals("Todas as disciplinas")) {
                String disciplinaSelecionada = comboDisciplina.getSelectedItem().toString();
                int codigoDisciplina = Integer.parseInt(disciplinaSelecionada.split("\\(")[1].replace(")", ""));
                stmt.setInt(3, codigoDisciplina);
            }
            
            ResultSet rs = stmt.executeQuery();
            
            double faturamentoGeral = 0;
            int totalMatriculas = 0;
            
            while (rs.next()) {
                double faturamento = rs.getDouble("faturamentoTotal");
                modeloTabela.addRow(new Object[]{
                    rs.getString("nomeDisciplina"),
                    rs.getString("periodo"),
                    "👥 " + rs.getInt("totalMatriculas"),
                    "💰 R$ " + String.format("%.2f", faturamento)
                });
                faturamentoGeral += faturamento;
                totalMatriculas += rs.getInt("totalMatriculas");
            }
            
            if (modeloTabela.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, 
                    "ℹ️ Nenhuma matrícula encontrada no período especificado.", 
                    "Informação", 
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Adicionar linha de total geral
                modeloTabela.addRow(new Object[]{
                    "📊 **TOTAL GERAL**",
                    "",
                    "👥 " + totalMatriculas,
                    "💰 R$ " + String.format("%.2f", faturamentoGeral)
                });
                
                setTitle("💰 Faturamento por Período - Total: R$ " + String.format("%.2f", faturamentoGeral));
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao consultar faturamento: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void limparCampos() {
        txtDataInicio.setText("");
        txtDataFim.setText("");
        comboDisciplina.setSelectedIndex(0);
        modeloTabela.setRowCount(0);
        setTitle("💰 Faturamento por Período");
    }
}