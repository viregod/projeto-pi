package visao;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Login extends JFrame {
    private JTextField txtLogin;
    private JPasswordField txtSenha;
    
    public Login() {
        initComponents();
    }
    
    private void initComponents() {
        setTitle("Login - Sistema de Matrícula");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Título
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel lblTitulo = new JLabel("Sistema de Controle de Matrícula", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(lblTitulo, gbc);
        
        // Espaço
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        panel.add(Box.createVerticalStrut(20), gbc);
        
        // Login
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        panel.add(new JLabel("Login:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 2;
        txtLogin = new JTextField(15);
        panel.add(txtLogin, gbc);
        
        // Senha
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Senha:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 3;
        txtSenha = new JPasswordField(15);
        panel.add(txtSenha, gbc);
        
        // Botões
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        JPanel panelBotoes = new JPanel();
        JButton btnLogin = new JButton("Entrar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnLogin.addActionListener(this::fazerLogin);
        btnCancelar.addActionListener(e -> System.exit(0));
        
        panelBotoes.add(btnLogin);
        panelBotoes.add(btnCancelar);
        panel.add(panelBotoes, gbc);
        
        // Enter no campo de senha também faz login
        txtSenha.addActionListener(this::fazerLogin);
        
        getContentPane().add(panel);
        pack();
        setLocationRelativeTo(null);
    }
    
    private void fazerLogin(ActionEvent e) {
        String login = txtLogin.getText();
        String senha = new String(txtSenha.getPassword());
        
        // Login simples
        if ("admin".equals(login) && "admin".equals(senha)) {
            new TelaPrincipal().setVisible(true);
            dispose(); // Fecha a tela de login
        } else {
            JOptionPane.showMessageDialog(this, "Login ou senha incorretos!", "Erro", JOptionPane.ERROR_MESSAGE);
            txtSenha.setText("");
            txtSenha.requestFocus();
        }
    }
    
    // MÉTODO MAIN AQUI - Esta é a classe principal agora
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }
}