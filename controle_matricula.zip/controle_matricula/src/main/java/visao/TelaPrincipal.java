package visao;

import javax.swing.*;
import java.awt.*;

public class TelaPrincipal extends JFrame {
    private JDesktopPane desktopPane;
    
    public TelaPrincipal() {
        // Aplica os estilos globais antes de inicializar
        Estilos.aplicarEstiloGlobal();
        initComponents();
        setExtendedState(MAXIMIZED_BOTH);
    }
    
    private void initComponents() {
        setTitle("🎓 Sistema de Controle de Matrícula");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // DesktopPane para MDI com cor personalizada
        desktopPane = new JDesktopPane();
        desktopPane.setBackground(Estilos.COR_FUNDO);
        setContentPane(desktopPane);
        
        // Menu Bar com estilo melhorado
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(Estilos.COR_PRIMARIA);
        menuBar.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        // Menu Cadastros
        JMenu menuCadastros = criarMenu("📋 Cadastros", 'C');
        
        JMenuItem itemPessoa = criarMenuItem("👥 Pessoas", 'P', e -> abrirTelaPessoa());
        JMenuItem itemDisciplina = criarMenuItem("📚 Disciplinas", 'D', e -> abrirTelaDisciplina());
        JMenuItem itemMatricula = criarMenuItem("🎫 Matrículas", 'M', e -> abrirTelaMatricula());
        
        menuCadastros.add(itemPessoa);
        menuCadastros.add(itemDisciplina);
        menuCadastros.add(itemMatricula);
        
        // Menu Relatórios
        JMenu menuRelatorios = criarMenu("📊 Relatórios", 'R');
        
        JMenuItem itemFaturamento = criarMenuItem("💰 Faturamento por Período", 'F', e -> abrirTelaFaturamento());
        JMenuItem itemDisciplinasProfessor = criarMenuItem("👨‍🏫 Disciplinas por Professor", 'P', e -> abrirTelaDisciplinasProfessor());
        JMenuItem itemDisciplinasAluno = criarMenuItem("👨‍🎓 Disciplinas por Aluno", 'A', e -> abrirTelaDisciplinasAluno());
        
        menuRelatorios.add(itemFaturamento);
        menuRelatorios.add(itemDisciplinasProfessor);
        menuRelatorios.add(itemDisciplinasAluno);
        
        // Menu Sistema
        JMenu menuSistema = criarMenu("⚙️ Sistema", 'S');
        JMenuItem itemSair = criarMenuItem("🚪 Sair", 'S', e -> sair());
        menuSistema.add(itemSair);
        
        menuBar.add(menuCadastros);
        menuBar.add(menuRelatorios);
        menuBar.add(Box.createHorizontalGlue()); // Empurra o último menu para direita
        menuBar.add(menuSistema);
        
        setJMenuBar(menuBar);
        
        // Adiciona um painel de boas-vindas centralizado
        adicionarPainelBoasVindas();
    }
    
    private JMenu criarMenu(String texto, char mnemonic) {
        JMenu menu = new JMenu(texto);
        menu.setMnemonic(mnemonic);
        menu.setForeground(Color.WHITE);
        menu.setFont(Estilos.FONTE_NEGRITO);
        return menu;
    }
    
    private JMenuItem criarMenuItem(String texto, char mnemonic, java.awt.event.ActionListener action) {
        JMenuItem item = new JMenuItem(texto);
        item.setMnemonic(mnemonic);
        item.addActionListener(action);
        item.setFont(Estilos.FONTE_NORMAL);
        return item;
    }
    
    private void adicionarPainelBoasVindas() {
        JPanel painelBoasVindas = new JPanel(new BorderLayout());
        painelBoasVindas.setBackground(Estilos.COR_FUNDO);
        painelBoasVindas.setBorder(BorderFactory.createEmptyBorder(100, 50, 100, 50));
        
        JLabel lblTitulo = new JLabel("🎓 Bem-vindo ao Sistema de Controle de Matrícula", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitulo.setForeground(Estilos.COR_PRIMARIA);
        
        JLabel lblSubtitulo = new JLabel("Selecione uma opção no menu acima para começar", JLabel.CENTER);
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblSubtitulo.setForeground(Estilos.COR_TEXTO);
        lblSubtitulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        painelBoasVindas.add(lblTitulo, BorderLayout.CENTER);
        painelBoasVindas.add(lblSubtitulo, BorderLayout.SOUTH);
        
        desktopPane.add(painelBoasVindas);
        painelBoasVindas.setBounds(0, 0, desktopPane.getWidth(), desktopPane.getHeight());
    }
    
    private void abrirTelaPessoa() {
        TelaPessoa tela = new TelaPessoa();
        desktopPane.add(tela);
        tela.setVisible(true);
        centralizarTela(tela);
    }
    
    private void abrirTelaDisciplina() {
        TelaDisciplina tela = new TelaDisciplina();
        desktopPane.add(tela);
        tela.setVisible(true);
        centralizarTela(tela);
    }
    
    private void abrirTelaMatricula() {
        TelaMatricula tela = new TelaMatricula();
        desktopPane.add(tela);
        tela.setVisible(true);
        centralizarTela(tela);
    }
    
    private void abrirTelaFaturamento() {
        TelaFaturamento tela = new TelaFaturamento();
        desktopPane.add(tela);
        tela.setVisible(true);
        centralizarTela(tela);
    }
    
    private void abrirTelaDisciplinasProfessor() {
        TelaDisciplinasProfessor tela = new TelaDisciplinasProfessor();
        desktopPane.add(tela);
        tela.setVisible(true);
        centralizarTela(tela);
    }
    
    private void abrirTelaDisciplinasAluno() {
        TelaDisciplinasAluno tela = new TelaDisciplinasAluno();
        desktopPane.add(tela);
        tela.setVisible(true);
        centralizarTela(tela);
    }
    
    private void centralizarTela(JInternalFrame tela) {
        Dimension desktopSize = desktopPane.getSize();
        Dimension telaSize = tela.getSize();
        tela.setLocation((desktopSize.width - telaSize.width) / 2, 
                         (desktopSize.height - telaSize.height) / 2);
    }
    
    private void sair() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Deseja realmente sair do sistema?",
            "Confirmação de Saída",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
            
        if (confirm == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
}