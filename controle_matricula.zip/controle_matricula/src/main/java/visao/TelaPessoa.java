package visao;

import dao.PessoaDAO;
import modelo.Pessoa;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaPessoa extends JInternalFrame {
    private JTextField txtNome, txtEndereco, txtUF, txtTelefone, txtCPF, txtEmail;
    private JComboBox<String> comboTipo;
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    private PessoaDAO pessoaDAO;
    private JButton btnSalvar, btnEditar;
    private boolean editando = false;
    private int idEditando = -1;
    
    public TelaPessoa() {
        initComponents();
        pessoaDAO = new PessoaDAO();
        carregarDados();
    }
    
    private void initComponents() {
        setTitle("👥 Cadastro de Pessoas");
        setSize(950, 650);
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        // Removido setFrameIcon que causava erro
        
        // Painel principal
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Estilos.COR_FUNDO);
        
        // Painel de formulário
        JPanel panelForm = Estilos.criarPainelComBorda("📝 Dados da Pessoa");
        panelForm.setLayout(new GridLayout(7, 2, 10, 10));
        panelForm.setBorder(BorderFactory.createCompoundBorder(
            panelForm.getBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        panelForm.add(criarLabel("Nome:*"));
        txtNome = criarTextField();
        panelForm.add(txtNome);
        
        panelForm.add(criarLabel("Endereço:"));
        txtEndereco = criarTextField();
        panelForm.add(txtEndereco);
        
        panelForm.add(criarLabel("UF:"));
        txtUF = criarTextField();
        panelForm.add(txtUF);
        
        panelForm.add(criarLabel("Telefone:"));
        txtTelefone = criarTextField();
        panelForm.add(txtTelefone);
        
        panelForm.add(criarLabel("CPF:*"));
        txtCPF = criarTextField();
        panelForm.add(txtCPF);
        
        panelForm.add(criarLabel("E-mail:"));
        txtEmail = criarTextField();
        panelForm.add(txtEmail);
        
        panelForm.add(criarLabel("Tipo:*"));
        comboTipo = new JComboBox<>(new String[]{"ALUNO", "PROFESSOR"});
        comboTipo.setFont(Estilos.FONTE_NORMAL);
        comboTipo.setBackground(Color.WHITE);
        panelForm.add(comboTipo);
        
        // Painel de botões
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotoes.setBackground(Color.WHITE);
        
        btnSalvar = Estilos.criarBotaoSucesso("💾 Salvar");
        btnEditar = Estilos.criarBotaoPrimario("✏️ Editar");
        JButton btnExcluir = Estilos.criarBotaoPerigo("🗑️ Excluir");
        JButton btnLimpar = Estilos.criarBotaoSecundario("🧹 Limpar");
        
        btnSalvar.addActionListener(e -> salvarPessoa());
        btnExcluir.addActionListener(e -> excluirPessoa());
        btnLimpar.addActionListener(e -> limparCampos());
        btnEditar.addActionListener(e -> prepararEdicao());
        
        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnEditar);
        panelBotoes.add(btnExcluir);
        panelBotoes.add(btnLimpar);
        
        // Tabela
        modeloTabela = new DefaultTableModel(
            new Object[]{"ID", "Nome", "CPF", "Telefone", "E-mail", "Tipo"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabela = new JTable(modeloTabela);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setFont(Estilos.FONTE_NORMAL);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(Estilos.FONTE_NEGRITO);
        tabela.getTableHeader().setBackground(Estilos.COR_PRIMARIA);
        tabela.getTableHeader().setForeground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Estilos.COR_PRIMARIA, 1), 
            "📋 Lista de Pessoas", 
            0, 0, 
            Estilos.FONTE_NEGRITO, 
            Estilos.COR_PRIMARIA
        ));
        
        // Adicionar componentes ao painel principal
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(Estilos.COR_FUNDO);
        panelNorte.add(panelForm, BorderLayout.CENTER);
        panelNorte.add(panelBotoes, BorderLayout.SOUTH);
        
        panel.add(panelNorte, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        getContentPane().add(panel);
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(Estilos.FONTE_NEGRITO);
        label.setForeground(Estilos.COR_TEXTO);
        return label;
    }
    
    private JTextField criarTextField() {
        JTextField field = new JTextField();
        field.setFont(Estilos.FONTE_NORMAL);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }
    
    private void salvarPessoa() {
        if (!validarCampos()) {
            return;
        }
        
        try {
            Pessoa pessoa = new Pessoa(
                txtNome.getText().trim(),
                txtEndereco.getText().trim(),
                txtUF.getText().trim().toUpperCase(),
                txtTelefone.getText().trim(),
                txtCPF.getText().trim(),
                txtEmail.getText().trim(),
                comboTipo.getSelectedItem().toString()
            );
            
            if (editando) {
                pessoa.setIdPessoa(idEditando);
                pessoaDAO.atualizar(pessoa);
            } else {
                pessoaDAO.inserir(pessoa);
                JOptionPane.showMessageDialog(this, 
                    "✅ Pessoa cadastrada com sucesso!", 
                    "Sucesso", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
            
            carregarDados();
            limparCampos();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao salvar pessoa: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void prepararEdicao() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma pessoa para editar.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        idEditando = (int) modeloTabela.getValueAt(linha, 0);
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        String cpf = (String) modeloTabela.getValueAt(linha, 2);
        String telefone = (String) modeloTabela.getValueAt(linha, 3);
        String email = (String) modeloTabela.getValueAt(linha, 4);
        String tipo = (String) modeloTabela.getValueAt(linha, 5);
        
        // Preenche os campos com os dados selecionados
        txtNome.setText(nome);
        txtCPF.setText(cpf.replaceAll("[^0-9]", "")); // Remove formatação do CPF
        txtTelefone.setText(telefone != null ? telefone : "");
        txtEmail.setText(email != null ? email : "");
        comboTipo.setSelectedItem(tipo);
        
        editando = true;
        btnSalvar.setText("💾 Atualizar");
        btnEditar.setEnabled(false);
        
        JOptionPane.showMessageDialog(this, 
            "✏️ Editando pessoa: " + nome + "\nAltere os dados e clique em 'Atualizar'.", 
            "Modo Edição", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void excluirPessoa() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma pessoa para excluir.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int id = (int) modeloTabela.getValueAt(linha, 0);
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "🗑️ Deseja realmente excluir a pessoa:\n" + nome + " (ID: " + id + ")?", 
            "Confirmação de Exclusão", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            pessoaDAO.excluir(id);
            carregarDados();
            limparCampos();
        }
    }
    
    private void limparCampos() {
        txtNome.setText("");
        txtEndereco.setText("");
        txtUF.setText("");
        txtTelefone.setText("");
        txtCPF.setText("");
        txtEmail.setText("");
        comboTipo.setSelectedIndex(0);
        txtNome.requestFocus();
        
        // Reset do modo edição
        editando = false;
        idEditando = -1;
        btnSalvar.setText("💾 Salvar");
        btnEditar.setEnabled(true);
    }
    
    private boolean validarCampos() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo Nome é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtNome.requestFocus();
            return false;
        }
        
        if (txtCPF.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo CPF é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtCPF.requestFocus();
            return false;
        }
        
        String cpf = txtCPF.getText().trim().replaceAll("[^0-9]", "");
        if (cpf.length() != 11) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ CPF deve conter 11 dígitos!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtCPF.requestFocus();
            return false;
        }
        
        String uf = txtUF.getText().trim().toUpperCase();
        if (!uf.isEmpty() && uf.length() != 2) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ UF deve ter 2 caracteres!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtUF.requestFocus();
            return false;
        }
        
        return true;
    }
    
    private void carregarDados() {
        modeloTabela.setRowCount(0);
        List<Pessoa> pessoas = pessoaDAO.listar();
        
        for (Pessoa p : pessoas) {
            modeloTabela.addRow(new Object[]{
                p.getIdPessoa(),
                p.getNomePessoa(),
                formatarCPF(p.getCpf()),
                p.getTelefone(),
                p.getEmail(),
                p.getTipo()
            });
        }
        
        setTitle("👥 Cadastro de Pessoas - Total: " + pessoas.size() + " registros");
    }
    
    private String formatarCPF(String cpf) {
        if (cpf == null || cpf.length() != 11) {
            return cpf;
        }
        return cpf.substring(0, 3) + "." + cpf.substring(3, 6) + "." + cpf.substring(6, 9) + "-" + cpf.substring(9);
    }
}