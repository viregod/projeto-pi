package visao;

import dao.DisciplinaDAO;
import dao.PessoaDAO;
import modelo.Disciplina;
import modelo.Pessoa;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaDisciplina extends JInternalFrame {
    private JTextField txtNome, txtCargaHoraria, txtLimiteAlunos;
    private JComboBox<Pessoa> comboProfessor;
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    private DisciplinaDAO disciplinaDAO;
    private PessoaDAO pessoaDAO;
    private JButton btnSalvar, btnEditar;
    private boolean editando = false;
    private int codigoEditando = -1;
    
    public TelaDisciplina() {
        initComponents();
        disciplinaDAO = new DisciplinaDAO();
        pessoaDAO = new PessoaDAO();
        carregarProfessores();
        carregarDados();
    }
    
    private void initComponents() {
        setTitle("📚 Cadastro de Disciplinas");
        setSize(950, 650);
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        
        // Painel principal
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Estilos.COR_FUNDO);
        
        // Painel de formulário
        JPanel panelForm = Estilos.criarPainelComBorda("📝 Dados da Disciplina");
        panelForm.setLayout(new GridLayout(4, 2, 10, 10));
        panelForm.setBorder(BorderFactory.createCompoundBorder(
            panelForm.getBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        panelForm.add(criarLabel("Nome:*"));
        txtNome = criarTextField();
        panelForm.add(txtNome);
        
        panelForm.add(criarLabel("Carga Horária:*"));
        txtCargaHoraria = criarTextField();
        panelForm.add(txtCargaHoraria);
        
        panelForm.add(criarLabel("Professor:*"));
        comboProfessor = new JComboBox<>();
        comboProfessor.setFont(Estilos.FONTE_NORMAL);
        comboProfessor.setBackground(Color.WHITE);
        panelForm.add(comboProfessor);
        
        panelForm.add(criarLabel("Limite de Alunos:*"));
        txtLimiteAlunos = criarTextField();
        panelForm.add(txtLimiteAlunos);
        
        // Painel de botões
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotoes.setBackground(Color.WHITE);
        
        btnSalvar = Estilos.criarBotaoSucesso("💾 Salvar");
        btnEditar = Estilos.criarBotaoPrimario("✏️ Editar");
        JButton btnExcluir = Estilos.criarBotaoPerigo("🗑️ Excluir");
        JButton btnLimpar = Estilos.criarBotaoSecundario("🧹 Limpar");
        
        btnSalvar.addActionListener(e -> salvarDisciplina());
        btnExcluir.addActionListener(e -> excluirDisciplina());
        btnLimpar.addActionListener(e -> limparCampos());
        btnEditar.addActionListener(e -> prepararEdicao());
        
        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnEditar);
        panelBotoes.add(btnExcluir);
        panelBotoes.add(btnLimpar);
        
        // Tabela
        modeloTabela = new DefaultTableModel(
            new Object[]{"Código", "Nome", "Carga Horária", "Professor", "Limite Alunos"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabela = new JTable(modeloTabela);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setFont(Estilos.FONTE_NORMAL);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(Estilos.FONTE_NEGRITO);
        tabela.getTableHeader().setBackground(Estilos.COR_PRIMARIA);
        tabela.getTableHeader().setForeground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Estilos.COR_PRIMARIA, 1), 
            "📋 Lista de Disciplinas", 
            0, 0, 
            Estilos.FONTE_NEGRITO, 
            Estilos.COR_PRIMARIA
        ));
        
        // Adicionar componentes ao painel principal
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(Estilos.COR_FUNDO);
        panelNorte.add(panelForm, BorderLayout.CENTER);
        panelNorte.add(panelBotoes, BorderLayout.SOUTH);
        
        panel.add(panelNorte, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        getContentPane().add(panel);
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(Estilos.FONTE_NEGRITO);
        label.setForeground(Estilos.COR_TEXTO);
        return label;
    }
    
    private JTextField criarTextField() {
        JTextField field = new JTextField();
        field.setFont(Estilos.FONTE_NORMAL);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }
    
    private void carregarProfessores() {
        List<Pessoa> pessoas = pessoaDAO.listar();
        for (Pessoa p : pessoas) {
            if ("PROFESSOR".equals(p.getTipo())) {
                comboProfessor.addItem(p);
            }
        }
    }
    
    private void salvarDisciplina() {
        if (!validarCampos()) {
            return;
        }
        
        try {
            Pessoa professor = (Pessoa) comboProfessor.getSelectedItem();
            if (professor == null) {
                JOptionPane.showMessageDialog(this, 
                    "⚠️ Selecione um professor!", 
                    "Aviso", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Disciplina disciplina = new Disciplina(
                txtNome.getText().trim(),
                Integer.parseInt(txtCargaHoraria.getText().trim()),
                professor,
                Integer.parseInt(txtLimiteAlunos.getText().trim())
            );
            
            if (editando) {
                disciplina.setCodigo(codigoEditando);
                disciplinaDAO.atualizar(disciplina);
            } else {
                disciplinaDAO.inserir(disciplina);
                JOptionPane.showMessageDialog(this, 
                    "✅ Disciplina cadastrada com sucesso!", 
                    "Sucesso", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
            
            carregarDados();
            limparCampos();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Carga horária e limite de alunos devem ser números válidos!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao salvar disciplina: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void prepararEdicao() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma disciplina para editar.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        codigoEditando = (int) modeloTabela.getValueAt(linha, 0);
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        String cargaHoraria = ((String) modeloTabela.getValueAt(linha, 2)).replace(" horas", "");
        String professorNome = (String) modeloTabela.getValueAt(linha, 3);
        int limiteAlunos = (int) modeloTabela.getValueAt(linha, 4);
        
        // Preenche os campos com os dados selecionados
        txtNome.setText(nome);
        txtCargaHoraria.setText(cargaHoraria);
        txtLimiteAlunos.setText(String.valueOf(limiteAlunos));
        
        // Seleciona o professor correto no combobox
        for (int i = 0; i < comboProfessor.getItemCount(); i++) {
            Pessoa prof = comboProfessor.getItemAt(i);
            if (prof.getNomePessoa().equals(professorNome)) {
                comboProfessor.setSelectedIndex(i);
                break;
            }
        }
        
        editando = true;
        btnSalvar.setText("💾 Atualizar");
        btnEditar.setEnabled(false);
        
        JOptionPane.showMessageDialog(this, 
            "✏️ Editando disciplina: " + nome + "\nAltere os dados e clique em 'Atualizar'.", 
            "Modo Edição", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void excluirDisciplina() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma disciplina para excluir.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int codigo = (int) modeloTabela.getValueAt(linha, 0);
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "🗑️ Deseja realmente excluir a disciplina:\n" + nome + " (Código: " + codigo + ")?", 
            "Confirmação de Exclusão", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            disciplinaDAO.excluir(codigo);
            carregarDados();
            limparCampos();
        }
    }
    
    private void limparCampos() {
        txtNome.setText("");
        txtCargaHoraria.setText("");
        txtLimiteAlunos.setText("");
        if (comboProfessor.getItemCount() > 0) {
            comboProfessor.setSelectedIndex(0);
        }
        
        // Reset do modo edição
        editando = false;
        codigoEditando = -1;
        btnSalvar.setText("💾 Salvar");
        btnEditar.setEnabled(true);
    }
    
    private boolean validarCampos() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo Nome é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtNome.requestFocus();
            return false;
        }
        
        if (txtCargaHoraria.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo Carga Horária é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtCargaHoraria.requestFocus();
            return false;
        }
        
        if (txtLimiteAlunos.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo Limite de Alunos é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtLimiteAlunos.requestFocus();
            return false;
        }
        
        try {
            int cargaHoraria = Integer.parseInt(txtCargaHoraria.getText().trim());
            if (cargaHoraria <= 0) {
                JOptionPane.showMessageDialog(this, 
                    "⚠️ Carga horária deve ser maior que zero!", 
                    "Validação", 
                    JOptionPane.WARNING_MESSAGE);
                txtCargaHoraria.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Carga horária deve ser um número válido!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtCargaHoraria.requestFocus();
            return false;
        }
        
        try {
            int limiteAlunos = Integer.parseInt(txtLimiteAlunos.getText().trim());
            if (limiteAlunos <= 0) {
                JOptionPane.showMessageDialog(this, 
                    "⚠️ Limite de alunos deve ser maior que zero!", 
                    "Validação", 
                    JOptionPane.WARNING_MESSAGE);
                txtLimiteAlunos.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Limite de alunos deve ser um número válido!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtLimiteAlunos.requestFocus();
            return false;
        }
        
        return true;
    }
    
    private void carregarDados() {
        modeloTabela.setRowCount(0);
        List<Disciplina> disciplinas = disciplinaDAO.listar();
        
        for (Disciplina d : disciplinas) {
            modeloTabela.addRow(new Object[]{
                d.getCodigo(),
                d.getNomeDisciplina(),
                d.getCargaHoraria() + " horas",
                d.getProfessor().getNomePessoa(),
                d.getLimiteAlunos()
            });
        }
        
        setTitle("📚 Cadastro de Disciplinas - Total: " + disciplinas.size() + " registros");
    }
}