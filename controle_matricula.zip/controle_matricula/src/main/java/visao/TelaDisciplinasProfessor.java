package visao;

import conexao.Conexao;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TelaDisciplinasProfessor extends JInternalFrame {
    private JComboBox<String> comboProfessor;
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    
    public TelaDisciplinasProfessor() {
        initComponents();
        carregarProfessores();
    }
    
    private void initComponents() {
        setTitle("👨‍🏫 Disciplinas por Professor");
        setSize(900, 550);
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Estilos.COR_FUNDO);
        
        // Painel de filtros
        JPanel panelFiltros = Estilos.criarPainelComBorda("🔍 Selecionar Professor");
        panelFiltros.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelFiltros.setBorder(BorderFactory.createCompoundBorder(
            panelFiltros.getBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        panelFiltros.add(criarLabel("Professor:"));
        comboProfessor = new JComboBox<>();
        comboProfessor.setPreferredSize(new Dimension(300, 30));
        comboProfessor.setFont(Estilos.FONTE_NORMAL);
        panelFiltros.add(comboProfessor);
        
        JButton btnConsultar = Estilos.criarBotaoPrimario("🔎 Consultar");
        btnConsultar.addActionListener(e -> consultarDisciplinas());
        panelFiltros.add(btnConsultar);
        
        JButton btnTodos = Estilos.criarBotaoSecundario("📊 Mostrar Todos");
        btnTodos.addActionListener(e -> consultarTodos());
        panelFiltros.add(btnTodos);
        
        // Tabela
        modeloTabela = new DefaultTableModel(
            new Object[]{"Código", "Disciplina", "Carga Horária", "Professor", "Limite Alunos", "Total Matrículas", "Vagas Restantes"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabela = new JTable(modeloTabela);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setFont(Estilos.FONTE_NORMAL);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(Estilos.FONTE_NEGRITO);
        tabela.getTableHeader().setBackground(Estilos.COR_PRIMARIA);
        tabela.getTableHeader().setForeground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Estilos.COR_PRIMARIA, 1), 
            "📋 Resultado da Consulta", 
            0, 0, 
            Estilos.FONTE_NEGRITO, 
            Estilos.COR_PRIMARIA
        ));
        
        panel.add(panelFiltros, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        getContentPane().add(panel);
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(Estilos.FONTE_NEGRITO);
        label.setForeground(Estilos.COR_TEXTO);
        return label;
    }
    
    private void carregarProfessores() {
        String sql = "SELECT idPessoa, nomePessoa FROM pessoa WHERE tipo = 'PROFESSOR' ORDER BY nomePessoa";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            comboProfessor.removeAllItems();
            comboProfessor.addItem("Selecione um professor...");
            
            while (rs.next()) {
                String professor = rs.getString("nomePessoa") + " (ID: " + rs.getInt("idPessoa") + ")";
                comboProfessor.addItem(professor);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao carregar professores: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void consultarDisciplinas() {
        if (comboProfessor.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione um professor!", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        modeloTabela.setRowCount(0);
        
        String professorSelecionado = comboProfessor.getSelectedItem().toString();
        int idProfessor = Integer.parseInt(professorSelecionado.split("ID: ")[1].replace(")", ""));
        
        String sql = "SELECT d.codigo, d.nomeDisciplina, d.cargaHoraria, d.limiteAlunos, " +
                    "p.nomePessoa as professor, " +
                    "COUNT(m.idmat) as totalMatriculas, " +
                    "(d.limiteAlunos - COUNT(m.idmat)) as vagasRestantes " +
                    "FROM disciplina d " +
                    "INNER JOIN pessoa p ON d.professor = p.idPessoa " +
                    "LEFT JOIN matricula m ON d.codigo = m.disciplina " +
                    "WHERE d.professor = ? " +
                    "GROUP BY d.codigo, d.nomeDisciplina, d.cargaHoraria, d.limiteAlunos, p.nomePessoa " +
                    "ORDER BY d.nomeDisciplina";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idProfessor);
            ResultSet rs = stmt.executeQuery();
            
            int totalDisciplinas = 0;
            int totalMatriculas = 0;
            int totalVagas = 0;
            
            while (rs.next()) {
                int vagasRestantes = rs.getInt("vagasRestantes");
                String estiloVagas = vagasRestantes > 0 ? "✅" : "❌";
                
                modeloTabela.addRow(new Object[]{
                    rs.getInt("codigo"),
                    rs.getString("nomeDisciplina"),
                    rs.getInt("cargaHoraria") + " horas",
                    rs.getString("professor"),
                    rs.getInt("limiteAlunos"),
                    rs.getInt("totalMatriculas"),
                    estiloVagas + " " + vagasRestantes
                });
                totalDisciplinas++;
                totalMatriculas += rs.getInt("totalMatriculas");
                totalVagas += vagasRestantes;
            }
            
            if (totalDisciplinas == 0) {
                JOptionPane.showMessageDialog(this, 
                    "ℹ️ Este professor não ministra nenhuma disciplina.", 
                    "Informação", 
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                setTitle("👨‍🏫 Disciplinas por Professor - " + totalDisciplinas + " disciplina(s), " + 
                        totalMatriculas + " matrícula(s), " + totalVagas + " vaga(s) restante(s)");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao consultar disciplinas: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void consultarTodos() {
        modeloTabela.setRowCount(0);
        
        String sql = "SELECT d.codigo, d.nomeDisciplina, d.cargaHoraria, d.limiteAlunos, " +
                    "p.nomePessoa as professor, " +
                    "COUNT(m.idmat) as totalMatriculas, " +
                    "(d.limiteAlunos - COUNT(m.idmat)) as vagasRestantes " +
                    "FROM disciplina d " +
                    "INNER JOIN pessoa p ON d.professor = p.idPessoa " +
                    "LEFT JOIN matricula m ON d.codigo = m.disciplina " +
                    "GROUP BY d.codigo, d.nomeDisciplina, d.cargaHoraria, d.limiteAlunos, p.nomePessoa " +
                    "ORDER BY p.nomePessoa, d.nomeDisciplina";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            int totalDisciplinas = 0;
            int totalMatriculas = 0;
            int totalVagas = 0;
            
            while (rs.next()) {
                int vagasRestantes = rs.getInt("vagasRestantes");
                String estiloVagas = vagasRestantes > 0 ? "✅" : "❌";
                
                modeloTabela.addRow(new Object[]{
                    rs.getInt("codigo"),
                    rs.getString("nomeDisciplina"),
                    rs.getInt("cargaHoraria") + " horas",
                    rs.getString("professor"),
                    rs.getInt("limiteAlunos"),
                    rs.getInt("totalMatriculas"),
                    estiloVagas + " " + vagasRestantes
                });
                totalDisciplinas++;
                totalMatriculas += rs.getInt("totalMatriculas");
                totalVagas += vagasRestantes;
            }
            
            setTitle("👨‍🏫 Disciplinas por Professor - " + totalDisciplinas + " disciplina(s), " + 
                    totalMatriculas + " matrícula(s), " + totalVagas + " vaga(s) restante(s)");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao consultar disciplinas: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}