package visao;

import conexao.Conexao;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TelaDisciplinasAluno extends JInternalFrame {
    private JComboBox<String> comboAluno;
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    
    public TelaDisciplinasAluno() {
        initComponents();
        carregarAlunos();
    }
    
    private void initComponents() {
        setTitle("👨‍🎓 Disciplinas por Aluno");
        setSize(1000, 550);
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Estilos.COR_FUNDO);
        
        // Painel de filtros
        JPanel panelFiltros = Estilos.criarPainelComBorda("🔍 Selecionar Aluno");
        panelFiltros.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelFiltros.setBorder(BorderFactory.createCompoundBorder(
            panelFiltros.getBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        panelFiltros.add(criarLabel("Aluno:"));
        comboAluno = new JComboBox<>();
        comboAluno.setPreferredSize(new Dimension(300, 30));
        comboAluno.setFont(Estilos.FONTE_NORMAL);
        panelFiltros.add(comboAluno);
        
        JButton btnConsultar = Estilos.criarBotaoPrimario("🔎 Consultar");
        btnConsultar.addActionListener(e -> consultarDisciplinas());
        panelFiltros.add(btnConsultar);
        
        JButton btnTodos = Estilos.criarBotaoSecundario("📊 Mostrar Todos");
        btnTodos.addActionListener(e -> consultarTodos());
        panelFiltros.add(btnTodos);
        
        // Tabela
        modeloTabela = new DefaultTableModel(
            new Object[]{"ID Matrícula", "Disciplina", "Professor", "Data Matrícula", "Valor Pago", "Período", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabela = new JTable(modeloTabela);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setFont(Estilos.FONTE_NORMAL);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(Estilos.FONTE_NEGRITO);
        tabela.getTableHeader().setBackground(Estilos.COR_PRIMARIA);
        tabela.getTableHeader().setForeground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Estilos.COR_PRIMARIA, 1), 
            "📋 Resultado da Consulta", 
            0, 0, 
            Estilos.FONTE_NEGRITO, 
            Estilos.COR_PRIMARIA
        ));
        
        panel.add(panelFiltros, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        getContentPane().add(panel);
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(Estilos.FONTE_NEGRITO);
        label.setForeground(Estilos.COR_TEXTO);
        return label;
    }
    
    private void carregarAlunos() {
        String sql = "SELECT idPessoa, nomePessoa FROM pessoa WHERE tipo = 'ALUNO' ORDER BY nomePessoa";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            comboAluno.removeAllItems();
            comboAluno.addItem("Selecione um aluno...");
            
            while (rs.next()) {
                String aluno = rs.getString("nomePessoa") + " (ID: " + rs.getInt("idPessoa") + ")";
                comboAluno.addItem(aluno);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao carregar alunos: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void consultarDisciplinas() {
        if (comboAluno.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione um aluno!", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        modeloTabela.setRowCount(0);
        
        String alunoSelecionado = comboAluno.getSelectedItem().toString();
        int idAluno = Integer.parseInt(alunoSelecionado.split("ID: ")[1].replace(")", ""));
        String nomeAluno = alunoSelecionado.split(" \\(")[0];
        
        String sql = "SELECT m.idmat, d.nomeDisciplina, p.nomePessoa as professor, " +
                    "m.dataMatricula, m.valorPago, m.periodo, " +
                    "CASE WHEN m.dataMatricula >= CURDATE() - INTERVAL 6 MONTH THEN '🎓 Cursando' ELSE '✅ Concluído' END as status " +
                    "FROM matricula m " +
                    "INNER JOIN disciplina d ON m.disciplina = d.codigo " +
                    "INNER JOIN pessoa p ON d.professor = p.idPessoa " +
                    "WHERE m.aluno = ? " +
                    "ORDER BY m.dataMatricula DESC";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idAluno);
            ResultSet rs = stmt.executeQuery();
            
            int totalMatriculas = 0;
            double valorTotal = 0;
            
            while (rs.next()) {
                modeloTabela.addRow(new Object[]{
                    rs.getInt("idmat"),
                    rs.getString("nomeDisciplina"),
                    rs.getString("professor"),
                    rs.getDate("dataMatricula"),
                    "💰 " + String.format("R$ %.2f", rs.getDouble("valorPago")),
                    rs.getString("periodo"),
                    rs.getString("status")
                });
                totalMatriculas++;
                valorTotal += rs.getDouble("valorPago");
            }
            
            if (totalMatriculas == 0) {
                JOptionPane.showMessageDialog(this, 
                    "ℹ️ Este aluno não está matriculado em nenhuma disciplina.", 
                    "Informação", 
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                setTitle("👨‍🎓 Disciplinas por Aluno - " + nomeAluno + " - " + 
                        totalMatriculas + " matrícula(s) - Total: 💰 R$ " + String.format("%.2f", valorTotal));
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao consultar disciplinas: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void consultarTodos() {
        modeloTabela.setRowCount(0);
        
        String sql = "SELECT m.idmat, d.nomeDisciplina, p.nomePessoa as professor, " +
                    "a.nomePessoa as aluno, " +
                    "m.dataMatricula, m.valorPago, m.periodo, " +
                    "CASE WHEN m.dataMatricula >= CURDATE() - INTERVAL 6 MONTH THEN '🎓 Cursando' ELSE '✅ Concluído' END as status " +
                    "FROM matricula m " +
                    "INNER JOIN disciplina d ON m.disciplina = d.codigo " +
                    "INNER JOIN pessoa p ON d.professor = p.idPessoa " +
                    "INNER JOIN pessoa a ON m.aluno = a.idPessoa " +
                    "ORDER BY a.nomePessoa, m.dataMatricula DESC";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            int totalMatriculas = 0;
            double valorTotal = 0;
            String alunoAtual = "";
            int countAluno = 0;
            
            while (rs.next()) {
                String aluno = rs.getString("aluno");
                if (!aluno.equals(alunoAtual)) {
                    alunoAtual = aluno;
                    countAluno++;
                }
                
                modeloTabela.addRow(new Object[]{
                    rs.getInt("idmat"),
                    rs.getString("nomeDisciplina"),
                    rs.getString("professor"),
                    rs.getDate("dataMatricula"),
                    "💰 " + String.format("R$ %.2f", rs.getDouble("valorPago")),
                    rs.getString("periodo"),
                    rs.getString("status")
                });
                totalMatriculas++;
                valorTotal += rs.getDouble("valorPago");
            }
            
            setTitle("👨‍🎓 Disciplinas por Aluno - " + countAluno + " aluno(s), " + 
                    totalMatriculas + " matrícula(s) - Total: 💰 R$ " + String.format("%.2f", valorTotal));
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao consultar disciplinas: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}