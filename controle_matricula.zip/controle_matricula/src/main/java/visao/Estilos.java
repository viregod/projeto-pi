package visao;

import java.awt.*;
import javax.swing.*;

public class Estilos {
    
    // Cores do tema
    public static final Color COR_PRIMARIA = new Color(41, 128, 185);     // Azul principal
    public static final Color COR_SECUNDARIA = new Color(52, 152, 219);   // Azul claro
    public static final Color COR_SUCESSO = new Color(46, 204, 113);      // Verde
    public static final Color COR_AVISO = new Color(241, 196, 15);        // Amarelo
    public static final Color COR_PERIGO = new Color(231, 76, 60);        // Vermelho
    public static final Color COR_TEXTO = new Color(44, 62, 80);          // Azul escuro
    public static final Color COR_FUNDO = new Color(236, 240, 241);       // Cinza claro
    
    // Fontes
    public static final Font FONTE_TITULO = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font FONTE_NORMAL = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font FONTE_NEGRITO = new Font("Segoe UI", Font.BOLD, 12);
    
    public static void aplicarEstiloGlobal() {
        // Método simplificado - apenas define cores básicas
        // O Look and Feel do sistema será usado por padrão
    }
    
    public static JButton criarBotaoPrimario(String texto) {
        JButton botao = new JButton(texto);
        botao.setBackground(COR_PRIMARIA);
        botao.setForeground(Color.WHITE);
        botao.setFont(FONTE_NEGRITO);
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        return botao;
    }
    
    public static JButton criarBotaoSecundario(String texto) {
        JButton botao = new JButton(texto);
        botao.setBackground(Color.WHITE);
        botao.setForeground(COR_PRIMARIA);
        botao.setFont(FONTE_NEGRITO);
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_PRIMARIA, 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        return botao;
    }
    
    public static JButton criarBotaoSucesso(String texto) {
        JButton botao = new JButton(texto);
        botao.setBackground(COR_SUCESSO);
        botao.setForeground(Color.WHITE);
        botao.setFont(FONTE_NEGRITO);
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        return botao;
    }
    
    public static JButton criarBotaoPerigo(String texto) {
        JButton botao = new JButton(texto);
        botao.setBackground(COR_PERIGO);
        botao.setForeground(Color.WHITE);
        botao.setFont(FONTE_NEGRITO);
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        return botao;
    }
    
    public static JPanel criarPainelComBorda(String titulo) {
        JPanel painel = new JPanel();
        painel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COR_PRIMARIA, 1), 
            titulo, 
            0, 0, 
            FONTE_NEGRITO, 
            COR_PRIMARIA
        ));
        painel.setBackground(Color.WHITE);
        return painel;
    }
}