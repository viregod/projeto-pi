package visao;

import dao.MatriculaDAO;
import dao.DisciplinaDAO;
import dao.PessoaDAO;
import modelo.Matricula;
import modelo.Disciplina;
import modelo.Pessoa;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaMatricula extends JInternalFrame {
    private JComboBox<Disciplina> comboDisciplina;
    private JComboBox<Pessoa> comboAluno;
    private JTextField txtData, txtValor, txtPeriodo;
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    private MatriculaDAO matriculaDAO;
    private DisciplinaDAO disciplinaDAO;
    private PessoaDAO pessoaDAO;
    private JButton btnSalvar, btnEditar;
    private boolean editando = false;
    private int idEditando = -1;
    
    public TelaMatricula() {
        initComponents();
        matriculaDAO = new MatriculaDAO();
        disciplinaDAO = new DisciplinaDAO();
        pessoaDAO = new PessoaDAO();
        carregarDisciplinas();
        carregarAlunos();
        carregarDados();
    }
    
    private void initComponents() {
        setTitle("🎫 Cadastro de Matrículas");
        setSize(1000, 650);
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        
        // Painel principal
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Estilos.COR_FUNDO);
        
        // Painel de formulário
        JPanel panelForm = Estilos.criarPainelComBorda("📝 Dados da Matrícula");
        panelForm.setLayout(new GridLayout(5, 2, 10, 10));
        panelForm.setBorder(BorderFactory.createCompoundBorder(
            panelForm.getBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        panelForm.add(criarLabel("Disciplina:*"));
        comboDisciplina = new JComboBox<>();
        comboDisciplina.setFont(Estilos.FONTE_NORMAL);
        comboDisciplina.setBackground(Color.WHITE);
        panelForm.add(comboDisciplina);
        
        panelForm.add(criarLabel("Aluno:*"));
        comboAluno = new JComboBox<>();
        comboAluno.setFont(Estilos.FONTE_NORMAL);
        comboAluno.setBackground(Color.WHITE);
        panelForm.add(comboAluno);
        
        panelForm.add(criarLabel("Data (YYYY-MM-DD):*"));
        txtData = criarTextField();
        panelForm.add(txtData);
        
        panelForm.add(criarLabel("Valor Pago:*"));
        txtValor = criarTextField();
        panelForm.add(txtValor);
        
        panelForm.add(criarLabel("Período:*"));
        txtPeriodo = criarTextField();
        panelForm.add(txtPeriodo);
        
        // Painel de botões
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotoes.setBackground(Color.WHITE);
        
        btnSalvar = Estilos.criarBotaoSucesso("💾 Salvar");
        btnEditar = Estilos.criarBotaoPrimario("✏️ Editar");
        JButton btnExcluir = Estilos.criarBotaoPerigo("🗑️ Excluir");
        JButton btnLimpar = Estilos.criarBotaoSecundario("🧹 Limpar");
        
        btnSalvar.addActionListener(e -> salvarMatricula());
        btnExcluir.addActionListener(e -> excluirMatricula());
        btnLimpar.addActionListener(e -> limparCampos());
        btnEditar.addActionListener(e -> prepararEdicao());
        
        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnEditar);
        panelBotoes.add(btnExcluir);
        panelBotoes.add(btnLimpar);
        
        // Tabela
        modeloTabela = new DefaultTableModel(
            new Object[]{"ID", "Disciplina", "Aluno", "Data", "Valor", "Período"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabela = new JTable(modeloTabela);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setFont(Estilos.FONTE_NORMAL);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(Estilos.FONTE_NEGRITO);
        tabela.getTableHeader().setBackground(Estilos.COR_PRIMARIA);
        tabela.getTableHeader().setForeground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Estilos.COR_PRIMARIA, 1), 
            "📋 Lista de Matrículas", 
            0, 0, 
            Estilos.FONTE_NEGRITO, 
            Estilos.COR_PRIMARIA
        ));
        
        // Adicionar componentes ao painel principal
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(Estilos.COR_FUNDO);
        panelNorte.add(panelForm, BorderLayout.CENTER);
        panelNorte.add(panelBotoes, BorderLayout.SOUTH);
        
        panel.add(panelNorte, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        getContentPane().add(panel);
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(Estilos.FONTE_NEGRITO);
        label.setForeground(Estilos.COR_TEXTO);
        return label;
    }
    
    private JTextField criarTextField() {
        JTextField field = new JTextField();
        field.setFont(Estilos.FONTE_NORMAL);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }
    
    private void carregarDisciplinas() {
        List<Disciplina> disciplinas = disciplinaDAO.listar();
        for (Disciplina d : disciplinas) {
            comboDisciplina.addItem(d);
        }
    }
    
    private void carregarAlunos() {
        List<Pessoa> pessoas = pessoaDAO.listar();
        for (Pessoa p : pessoas) {
            if ("ALUNO".equals(p.getTipo())) {
                comboAluno.addItem(p);
            }
        }
    }
    
    private void salvarMatricula() {
        if (!validarCampos()) {
            return;
        }
        
        try {
            Disciplina disciplina = (Disciplina) comboDisciplina.getSelectedItem();
            Pessoa aluno = (Pessoa) comboAluno.getSelectedItem();
            
            if (disciplina == null || aluno == null) {
                JOptionPane.showMessageDialog(this, 
                    "⚠️ Selecione uma disciplina e um aluno!", 
                    "Aviso", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Verificar se é uma nova matrícula (não está editando)
            if (!editando) {
                // Verificar limite de alunos apenas para novas matrículas
                if (!matriculaDAO.verificarLimiteAlunos(disciplina.getCodigo())) {
                    JOptionPane.showMessageDialog(this, 
                        "⚠️ Limite de alunos atingido para esta disciplina!", 
                        "Aviso", 
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                // Verificar se aluno já está matriculado nesta disciplina
                if (matriculaDAO.verificarMatriculaExistente(aluno.getIdPessoa(), disciplina.getCodigo())) {
                    JOptionPane.showMessageDialog(this, 
                        "⚠️ Este aluno já está matriculado nesta disciplina!", 
                        "Aviso", 
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            
            Matricula matricula = new Matricula(
                disciplina,
                java.sql.Date.valueOf(txtData.getText().trim()),
                Double.parseDouble(txtValor.getText().trim()),
                aluno,
                txtPeriodo.getText().trim()
            );
            
            if (editando) {
                // Atualizar matrícula existente
                matricula.setIdmat(idEditando);
                matriculaDAO.atualizar(matricula);
            } else {
                // Inserir nova matrícula
                matriculaDAO.inserir(matricula);
                JOptionPane.showMessageDialog(this, 
                    "✅ Matrícula realizada com sucesso!", 
                    "Sucesso", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
            
            carregarDados();
            limparCampos();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro ao salvar matrícula: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void prepararEdicao() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma matrícula para editar.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        idEditando = (int) modeloTabela.getValueAt(linha, 0);
        String disciplinaNome = (String) modeloTabela.getValueAt(linha, 1);
        String alunoNome = (String) modeloTabela.getValueAt(linha, 2);
        String data = modeloTabela.getValueAt(linha, 3).toString();
        String valorStr = ((String) modeloTabela.getValueAt(linha, 4)).replace("R$ ", "").replace(",", ".");
        String periodo = (String) modeloTabela.getValueAt(linha, 5);
        
        // Preenche os campos com os dados selecionados
        txtData.setText(data);
        txtValor.setText(valorStr);
        txtPeriodo.setText(periodo);
        
        // Seleciona a disciplina correta no combobox
        for (int i = 0; i < comboDisciplina.getItemCount(); i++) {
            Disciplina disc = comboDisciplina.getItemAt(i);
            if (disc.getNomeDisciplina().equals(disciplinaNome)) {
                comboDisciplina.setSelectedIndex(i);
                break;
            }
        }
        
        // Seleciona o aluno correto no combobox
        for (int i = 0; i < comboAluno.getItemCount(); i++) {
            Pessoa aluno = comboAluno.getItemAt(i);
            if (aluno.getNomePessoa().equals(alunoNome)) {
                comboAluno.setSelectedIndex(i);
                break;
            }
        }
        
        editando = true;
        btnSalvar.setText("💾 Atualizar");
        btnEditar.setEnabled(false);
        
        JOptionPane.showMessageDialog(this, 
            "✏️ Editando matrícula ID: " + idEditando + "\nAltere os dados e clique em 'Atualizar'.", 
            "Modo Edição", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void excluirMatricula() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma matrícula para excluir.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int id = (int) modeloTabela.getValueAt(linha, 0);
        String disciplina = (String) modeloTabela.getValueAt(linha, 1);
        String aluno = (String) modeloTabela.getValueAt(linha, 2);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "🗑️ Deseja realmente excluir a matrícula:\n" + aluno + " em " + disciplina + " (ID: " + id + ")?", 
            "Confirmação de Exclusão", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            matriculaDAO.excluir(id);
            carregarDados();
            limparCampos();
        }
    }
    
    private void limparCampos() {
        txtData.setText("");
        txtValor.setText("");
        txtPeriodo.setText("");
        if (comboDisciplina.getItemCount() > 0) comboDisciplina.setSelectedIndex(0);
        if (comboAluno.getItemCount() > 0) comboAluno.setSelectedIndex(0);
        
        // Reset do modo edição
        editando = false;
        idEditando = -1;
        btnSalvar.setText("💾 Salvar");
        btnEditar.setEnabled(true);
    }
    
    private boolean validarCampos() {
        if (txtData.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo Data é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtData.requestFocus();
            return false;
        }
        
        if (txtValor.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo Valor Pago é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtValor.requestFocus();
            return false;
        }
        
        if (txtPeriodo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ O campo Período é obrigatório!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtPeriodo.requestFocus();
            return false;
        }
        
        // Validação da data
        try {
            java.sql.Date.valueOf(txtData.getText().trim());
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Data deve estar no formato YYYY-MM-DD!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtData.requestFocus();
            return false;
        }
        
        // Validação do valor
        try {
            double valor = Double.parseDouble(txtValor.getText().trim());
            if (valor <= 0) {
                JOptionPane.showMessageDialog(this, 
                    "⚠️ Valor deve ser maior que zero!", 
                    "Validação", 
                    JOptionPane.WARNING_MESSAGE);
                txtValor.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Valor deve ser um número válido!", 
                "Validação", 
                JOptionPane.WARNING_MESSAGE);
            txtValor.requestFocus();
            return false;
        }
        
        return true;
    }
    
    private void carregarDados() {
        modeloTabela.setRowCount(0);
        List<Matricula> matriculas = matriculaDAO.listar();
        
        for (Matricula m : matriculas) {
            modeloTabela.addRow(new Object[]{
                m.getIdmat(),
                m.getDisciplina().getNomeDisciplina(),
                m.getAluno().getNomePessoa(),
                m.getDataMatricula(),
                String.format("R$ %.2f", m.getValorPago()),
                m.getPeriodo()
            });
        }
        
        setTitle("🎫 Cadastro de Matrículas - Total: " + matriculas.size() + " registros");
    }
}