package modelo;

public class Pessoa {
    private int idPessoa;
    private String nomePessoa;
    private String endereco;
    private String uf;
    private String telefone;
    private String cpf;
    private String email;
    private String tipo; // NOVO CAMPO: "ALUNO" ou "PROFESSOR"
    
    // Construtores
    public Pessoa() {}
    
    // Construtor atualizado
    public Pessoa(String nomePessoa, String endereco, String uf, String telefone, String cpf, String email, String tipo) {
        this.nomePessoa = nomePessoa;
        this.endereco = endereco;
        this.uf = uf;
        this.telefone = telefone;
        this.cpf = cpf;
        this.email = email;
        this.tipo = tipo;
    }
    
    // Getters e Setters
    public int getIdPessoa() { return idPessoa; }
    public void setIdPessoa(int idPessoa) { this.idPessoa = idPessoa; }
    
    public String getNomePessoa() { return nomePessoa; }
    public void setNomePessoa(String nomePessoa) { this.nomePessoa = nomePessoa; }
    
    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    
    public String getUf() { return uf; }
    public void setUf(String uf) { this.uf = uf; }
    
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    
    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    // NOVOS GETTERS E SETTERS
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    
    @Override
    public String toString() {
        return nomePessoa + " (" + tipo + ")"; // Atualizado para mostrar o tipo
    }
}