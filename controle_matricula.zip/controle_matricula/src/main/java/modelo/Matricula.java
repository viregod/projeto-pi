package modelo;

import java.util.Date;

public class Matricula {
    private int idmat;
    private Disciplina disciplina;
    private Date dataMatricula;
    private double valorPago;
    private Pessoa aluno;
    private String periodo;
    
    // Construtores
    public Matricula() {}
    
    public Matricula(Disciplina disciplina, Date dataMatricula, double valorPago, Pessoa aluno, String periodo) {
        this.disciplina = disciplina;
        this.dataMatricula = dataMatricula;
        this.valorPago = valorPago;
        this.aluno = aluno;
        this.periodo = periodo;
    }
    
    // Getters e Setters
    public int getIdmat() { return idmat; }
    public void setIdmat(int idmat) { this.idmat = idmat; }
    
    public Disciplina getDisciplina() { return disciplina; }
    public void setDisciplina(Disciplina disciplina) { this.disciplina = disciplina; }
    
    public Date getDataMatricula() { return dataMatricula; }
    public void setDataMatricula(Date dataMatricula) { this.dataMatricula = dataMatricula; }
    
    public double getValorPago() { return valorPago; }
    public void setValorPago(double valorPago) { this.valorPago = valorPago; }
    
    public Pessoa getAluno() { return aluno; }
    public void setAluno(Pessoa aluno) { this.aluno = aluno; }
    
    public String getPeriodo() { return periodo; }
    public void setPeriodo(String periodo) { this.periodo = periodo; }
}