package dao;

import conexao.Conexao;
import modelo.Pessoa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PessoaDAO {
    
    public void inserir(Pessoa pessoa) {
        String sql = "INSERT INTO pessoa (nomePessoa, endereco, uf, telefone, cpf, email, tipo) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, pessoa.getNomePessoa());
            stmt.setString(2, pessoa.getEndereco());
            stmt.setString(3, pessoa.getUf());
            stmt.setString(4, pessoa.getTelefone());
            stmt.setString(5, pessoa.getCpf());
            stmt.setString(6, pessoa.getEmail());
            stmt.setString(7, pessoa.getTipo());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Pessoa cadastrada com sucesso!");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar pessoa: " + e.getMessage());
        }
    }
    
    public void atualizar(Pessoa pessoa) {
        String sql = "UPDATE pessoa SET nomePessoa=?, endereco=?, uf=?, telefone=?, cpf=?, email=?, tipo=? WHERE idPessoa=?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, pessoa.getNomePessoa());
            stmt.setString(2, pessoa.getEndereco());
            stmt.setString(3, pessoa.getUf());
            stmt.setString(4, pessoa.getTelefone());
            stmt.setString(5, pessoa.getCpf());
            stmt.setString(6, pessoa.getEmail());
            stmt.setString(7, pessoa.getTipo());
            stmt.setInt(8, pessoa.getIdPessoa());
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Pessoa atualizada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Pessoa não encontrada para atualização!");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar pessoa: " + e.getMessage());
        }
    }
    
    public Pessoa buscarPorId(int idPessoa) {
        String sql = "SELECT * FROM pessoa WHERE idPessoa = ?";
        Pessoa pessoa = null;
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idPessoa);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                pessoa = new Pessoa();
                pessoa.setIdPessoa(rs.getInt("idPessoa"));
                pessoa.setNomePessoa(rs.getString("nomePessoa"));
                pessoa.setEndereco(rs.getString("endereco"));
                pessoa.setUf(rs.getString("uf"));
                pessoa.setTelefone(rs.getString("telefone"));
                pessoa.setCpf(rs.getString("cpf"));
                pessoa.setEmail(rs.getString("email"));
                pessoa.setTipo(rs.getString("tipo"));
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar pessoa: " + e.getMessage());
        }
        
        return pessoa;
    }
    
    public List<Pessoa> listar() {
        List<Pessoa> pessoas = new ArrayList<>();
        String sql = "SELECT * FROM pessoa ORDER BY nomePessoa";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Pessoa p = new Pessoa();
                p.setIdPessoa(rs.getInt("idPessoa"));
                p.setNomePessoa(rs.getString("nomePessoa"));
                p.setEndereco(rs.getString("endereco"));
                p.setUf(rs.getString("uf"));
                p.setTelefone(rs.getString("telefone"));
                p.setCpf(rs.getString("cpf"));
                p.setEmail(rs.getString("email"));
                p.setTipo(rs.getString("tipo"));
                pessoas.add(p);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar pessoas: " + e.getMessage());
        }
        
        return pessoas;
    }
    
    public List<Pessoa> listarPorTipo(String tipo) {
        List<Pessoa> pessoas = new ArrayList<>();
        String sql = "SELECT * FROM pessoa WHERE tipo = ? ORDER BY nomePessoa";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, tipo);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Pessoa p = new Pessoa();
                p.setIdPessoa(rs.getInt("idPessoa"));
                p.setNomePessoa(rs.getString("nomePessoa"));
                p.setEndereco(rs.getString("endereco"));
                p.setUf(rs.getString("uf"));
                p.setTelefone(rs.getString("telefone"));
                p.setCpf(rs.getString("cpf"));
                p.setEmail(rs.getString("email"));
                p.setTipo(rs.getString("tipo"));
                pessoas.add(p);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar pessoas por tipo: " + e.getMessage());
        }
        
        return pessoas;
    }
    
    public void excluir(int idPessoa) {
        // Verificar se existem disciplinas ou matrículas associadas
        if (temAssociacoes(idPessoa)) {
            JOptionPane.showMessageDialog(null, "Não é possível excluir: existem disciplinas ou matrículas associadas a esta pessoa.");
            return;
        }
        
        String sql = "DELETE FROM pessoa WHERE idPessoa = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idPessoa);
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Pessoa excluída com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Pessoa não encontrada para exclusão!");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir pessoa: " + e.getMessage());
        }
    }
    
    public boolean existeCPF(String cpf, int idPessoaExcluir) {
        String sql = "SELECT COUNT(*) FROM pessoa WHERE cpf = ? AND idPessoa != ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cpf);
            stmt.setInt(2, idPessoaExcluir);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao verificar CPF: " + e.getMessage());
        }
        
        return false;
    }
    
    private boolean temAssociacoes(int idPessoa) {
        String sqlDisciplina = "SELECT COUNT(*) FROM disciplina WHERE professor = ?";
        String sqlMatricula = "SELECT COUNT(*) FROM matricula WHERE aluno = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt1 = conn.prepareStatement(sqlDisciplina);
             PreparedStatement stmt2 = conn.prepareStatement(sqlMatricula)) {
            
            stmt1.setInt(1, idPessoa);
            stmt2.setInt(1, idPessoa);
            
            ResultSet rs1 = stmt1.executeQuery();
            ResultSet rs2 = stmt2.executeQuery();
            
            if (rs1.next() && rs1.getInt(1) > 0) return true;
            if (rs2.next() && rs2.getInt(1) > 0) return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public int contarPorTipo(String tipo) {
        String sql = "SELECT COUNT(*) FROM pessoa WHERE tipo = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, tipo);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao contar pessoas: " + e.getMessage());
        }
        
        return 0;
    }
}