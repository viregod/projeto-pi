package dao;

import conexao.Conexao;
import modelo.Matricula;
import modelo.Disciplina;
import modelo.Pessoa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class MatriculaDAO {
    
    public void inserir(Matricula matricula) {
        String sql = "INSERT INTO matricula (disciplina, dataMatricula, valorPago, aluno, periodo) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, matricula.getDisciplina().getCodigo());
            stmt.setDate(2, new java.sql.Date(matricula.getDataMatricula().getTime()));
            stmt.setDouble(3, matricula.getValorPago());
            stmt.setInt(4, matricula.getAluno().getIdPessoa());
            stmt.setString(5, matricula.getPeriodo());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Matrícula realizada com sucesso!");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao realizar matrícula: " + e.getMessage());
        }
    }
    
    public void atualizar(Matricula matricula) {
        String sql = "UPDATE matricula SET disciplina=?, dataMatricula=?, valorPago=?, aluno=?, periodo=? WHERE idmat=?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, matricula.getDisciplina().getCodigo());
            stmt.setDate(2, new java.sql.Date(matricula.getDataMatricula().getTime()));
            stmt.setDouble(3, matricula.getValorPago());
            stmt.setInt(4, matricula.getAluno().getIdPessoa());
            stmt.setString(5, matricula.getPeriodo());
            stmt.setInt(6, matricula.getIdmat());
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Matrícula atualizada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Matrícula não encontrada para atualização!");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar matrícula: " + e.getMessage());
        }
    }
    
    public Matricula buscarPorId(int idMatricula) {
        String sql = "SELECT m.*, d.nomeDisciplina, p.nomePessoa as nomeAluno, p.tipo as tipoAluno " +
                    "FROM matricula m " +
                    "INNER JOIN disciplina d ON m.disciplina = d.codigo " +
                    "INNER JOIN pessoa p ON m.aluno = p.idPessoa " +
                    "WHERE m.idmat = ?";
        Matricula matricula = null;
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idMatricula);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                matricula = new Matricula();
                matricula.setIdmat(rs.getInt("idmat"));
                matricula.setDataMatricula(rs.getDate("dataMatricula"));
                matricula.setValorPago(rs.getDouble("valorPago"));
                matricula.setPeriodo(rs.getString("periodo"));
                
                // Criar objeto Disciplina
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("disciplina"));
                disciplina.setNomeDisciplina(rs.getString("nomeDisciplina"));
                matricula.setDisciplina(disciplina);
                
                // Criar objeto Pessoa para aluno
                Pessoa aluno = new Pessoa();
                aluno.setIdPessoa(rs.getInt("aluno"));
                aluno.setNomePessoa(rs.getString("nomeAluno"));
                aluno.setTipo(rs.getString("tipoAluno"));
                matricula.setAluno(aluno);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar matrícula: " + e.getMessage());
        }
        
        return matricula;
    }
    
    public List<Matricula> listar() {
        List<Matricula> matriculas = new ArrayList<>();
        String sql = "SELECT m.*, d.nomeDisciplina, p.nomePessoa as nomeAluno, p.tipo as tipoAluno " +
                    "FROM matricula m " +
                    "INNER JOIN disciplina d ON m.disciplina = d.codigo " +
                    "INNER JOIN pessoa p ON m.aluno = p.idPessoa " +
                    "ORDER BY m.dataMatricula DESC";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Matricula m = new Matricula();
                m.setIdmat(rs.getInt("idmat"));
                m.setDataMatricula(rs.getDate("dataMatricula"));
                m.setValorPago(rs.getDouble("valorPago"));
                m.setPeriodo(rs.getString("periodo"));
                
                // Criar objeto Disciplina
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("disciplina"));
                disciplina.setNomeDisciplina(rs.getString("nomeDisciplina"));
                m.setDisciplina(disciplina);
                
                // Criar objeto Pessoa para aluno
                Pessoa aluno = new Pessoa();
                aluno.setIdPessoa(rs.getInt("aluno"));
                aluno.setNomePessoa(rs.getString("nomeAluno"));
                aluno.setTipo(rs.getString("tipoAluno"));
                m.setAluno(aluno);
                
                matriculas.add(m);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar matrículas: " + e.getMessage());
        }
        
        return matriculas;
    }
    
    public void excluir(int idMatricula) {
        String sql = "DELETE FROM matricula WHERE idmat = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idMatricula);
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Matrícula excluída com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Matrícula não encontrada para exclusão!");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir matrícula: " + e.getMessage());
        }
    }
    
    public boolean verificarLimiteAlunos(int codigoDisciplina) {
        String sqlCountMatriculas = "SELECT COUNT(*) FROM matricula WHERE disciplina = ?";
        String sqlLimiteDisciplina = "SELECT limiteAlunos FROM disciplina WHERE codigo = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt1 = conn.prepareStatement(sqlCountMatriculas);
             PreparedStatement stmt2 = conn.prepareStatement(sqlLimiteDisciplina)) {
            
            stmt1.setInt(1, codigoDisciplina);
            stmt2.setInt(1, codigoDisciplina);
            
            ResultSet rs1 = stmt1.executeQuery();
            ResultSet rs2 = stmt2.executeQuery();
            
            if (rs1.next() && rs2.next()) {
                int totalMatriculas = rs1.getInt(1);
                int limiteAlunos = rs2.getInt(1);
                return totalMatriculas < limiteAlunos;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean verificarMatriculaExistente(int idAluno, int codigoDisciplina) {
        String sql = "SELECT COUNT(*) FROM matricula WHERE aluno = ? AND disciplina = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idAluno);
            stmt.setInt(2, codigoDisciplina);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public List<Matricula> listarPorAluno(int idAluno) {
        List<Matricula> matriculas = new ArrayList<>();
        String sql = "SELECT m.*, d.nomeDisciplina, p.nomePessoa as professor " +
                    "FROM matricula m " +
                    "INNER JOIN disciplina d ON m.disciplina = d.codigo " +
                    "INNER JOIN pessoa p ON d.professor = p.idPessoa " +
                    "WHERE m.aluno = ? " +
                    "ORDER BY m.dataMatricula DESC";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idAluno);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Matricula m = new Matricula();
                m.setIdmat(rs.getInt("idmat"));
                m.setDataMatricula(rs.getDate("dataMatricula"));
                m.setValorPago(rs.getDouble("valorPago"));
                m.setPeriodo(rs.getString("periodo"));
                
                // Criar objeto Disciplina
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("disciplina"));
                disciplina.setNomeDisciplina(rs.getString("nomeDisciplina"));
                
                // Criar objeto Pessoa para professor
                Pessoa professor = new Pessoa();
                professor.setNomePessoa(rs.getString("professor"));
                disciplina.setProfessor(professor);
                
                m.setDisciplina(disciplina);
                
                // Criar objeto Pessoa para aluno
                Pessoa aluno = new Pessoa();
                aluno.setIdPessoa(idAluno);
                m.setAluno(aluno);
                
                matriculas.add(m);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar matrículas do aluno: " + e.getMessage());
        }
        
        return matriculas;
    }
    
    public List<Matricula> listarPorDisciplina(int codigoDisciplina) {
        List<Matricula> matriculas = new ArrayList<>();
        String sql = "SELECT m.*, p.nomePessoa as nomeAluno " +
                    "FROM matricula m " +
                    "INNER JOIN pessoa p ON m.aluno = p.idPessoa " +
                    "WHERE m.disciplina = ? " +
                    "ORDER BY p.nomePessoa";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, codigoDisciplina);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Matricula m = new Matricula();
                m.setIdmat(rs.getInt("idmat"));
                m.setDataMatricula(rs.getDate("dataMatricula"));
                m.setValorPago(rs.getDouble("valorPago"));
                m.setPeriodo(rs.getString("periodo"));
                
                // Criar objeto Disciplina
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(codigoDisciplina);
                m.setDisciplina(disciplina);
                
                // Criar objeto Pessoa para aluno
                Pessoa aluno = new Pessoa();
                aluno.setIdPessoa(rs.getInt("aluno"));
                aluno.setNomePessoa(rs.getString("nomeAluno"));
                m.setAluno(aluno);
                
                matriculas.add(m);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar matrículas da disciplina: " + e.getMessage());
        }
        
        return matriculas;
    }
}