package dao;

import conexao.Conexao;
import modelo.Disciplina;
import modelo.Pessoa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class DisciplinaDAO {
    
    public void inserir(Disciplina disciplina) {
        String sql = "INSERT INTO disciplina (nomeDisciplina, cargaHoraria, professor, limiteAlunos) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, disciplina.getNomeDisciplina());
            stmt.setInt(2, disciplina.getCargaHoraria());
            stmt.setInt(3, disciplina.getProfessor().getIdPessoa());
            stmt.setInt(4, disciplina.getLimiteAlunos());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Disciplina cadastrada com sucesso!");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar disciplina: " + e.getMessage());
        }
    }
    
    public void atualizar(Disciplina disciplina) {
        String sql = "UPDATE disciplina SET nomeDisciplina=?, cargaHoraria=?, professor=?, limiteAlunos=? WHERE codigo=?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, disciplina.getNomeDisciplina());
            stmt.setInt(2, disciplina.getCargaHoraria());
            stmt.setInt(3, disciplina.getProfessor().getIdPessoa());
            stmt.setInt(4, disciplina.getLimiteAlunos());
            stmt.setInt(5, disciplina.getCodigo());
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Disciplina atualizada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Disciplina não encontrada para atualização!");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar disciplina: " + e.getMessage());
        }
    }
    
    public Disciplina buscarPorCodigo(int codigo) {
        String sql = "SELECT d.*, p.nomePessoa, p.cpf, p.tipo FROM disciplina d " +
                    "LEFT JOIN pessoa p ON d.professor = p.idPessoa WHERE d.codigo = ?";
        Disciplina disciplina = null;
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, codigo);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("codigo"));
                disciplina.setNomeDisciplina(rs.getString("nomeDisciplina"));
                disciplina.setCargaHoraria(rs.getInt("cargaHoraria"));
                disciplina.setLimiteAlunos(rs.getInt("limiteAlunos"));
                
                Pessoa professor = new Pessoa();
                professor.setIdPessoa(rs.getInt("professor"));
                professor.setNomePessoa(rs.getString("nomePessoa"));
                professor.setCpf(rs.getString("cpf"));
                professor.setTipo(rs.getString("tipo"));
                disciplina.setProfessor(professor);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar disciplina: " + e.getMessage());
        }
        
        return disciplina;
    }
    
    public List<Disciplina> listar() {
        List<Disciplina> disciplinas = new ArrayList<>();
        String sql = "SELECT d.*, p.nomePessoa, p.cpf, p.tipo FROM disciplina d " +
                    "LEFT JOIN pessoa p ON d.professor = p.idPessoa ORDER BY d.nomeDisciplina";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Disciplina d = new Disciplina();
                d.setCodigo(rs.getInt("codigo"));
                d.setNomeDisciplina(rs.getString("nomeDisciplina"));
                d.setCargaHoraria(rs.getInt("cargaHoraria"));
                d.setLimiteAlunos(rs.getInt("limiteAlunos"));
                
                Pessoa professor = new Pessoa();
                professor.setIdPessoa(rs.getInt("professor"));
                professor.setNomePessoa(rs.getString("nomePessoa"));
                professor.setCpf(rs.getString("cpf"));
                professor.setTipo(rs.getString("tipo"));
                d.setProfessor(professor);
                
                disciplinas.add(d);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar disciplinas: " + e.getMessage());
        }
        
        return disciplinas;
    }
    
    public void excluir(int codigo) {
        if (temMatriculasAssociadas(codigo)) {
            JOptionPane.showMessageDialog(null, "Não é possível excluir: existem matrículas associadas a esta disciplina.");
            return;
        }
        
        String sql = "DELETE FROM disciplina WHERE codigo = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, codigo);
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Disciplina excluída com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Disciplina não encontrada para exclusão!");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir disciplina: " + e.getMessage());
        }
    }
    
    private boolean temMatriculasAssociadas(int codigoDisciplina) {
        String sql = "SELECT COUNT(*) FROM matricula WHERE disciplina = ?";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, codigoDisciplina);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public List<Disciplina> listarPorProfessor(int idProfessor) {
        List<Disciplina> disciplinas = new ArrayList<>();
        String sql = "SELECT d.*, p.nomePessoa, p.cpf, p.tipo FROM disciplina d " +
                    "LEFT JOIN pessoa p ON d.professor = p.idPessoa " +
                    "WHERE d.professor = ? ORDER BY d.nomeDisciplina";
        
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idProfessor);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Disciplina d = new Disciplina();
                d.setCodigo(rs.getInt("codigo"));
                d.setNomeDisciplina(rs.getString("nomeDisciplina"));
                d.setCargaHoraria(rs.getInt("cargaHoraria"));
                d.setLimiteAlunos(rs.getInt("limiteAlunos"));
                
                Pessoa professor = new Pessoa();
                professor.setIdPessoa(rs.getInt("professor"));
                professor.setNomePessoa(rs.getString("nomePessoa"));
                professor.setCpf(rs.getString("cpf"));
                professor.setTipo(rs.getString("tipo"));
                d.setProfessor(professor);
                
                disciplinas.add(d);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar disciplinas do professor: " + e.getMessage());
        }
        
        return disciplinas;
    }
}